/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <bme680.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define Calibrate 1
#define DELAY_PERIOD_MS (15*1000)// 15 seconds
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define I2C_ADDR 0x27 // I2C address of the PCF8574
#define RS_BIT 0 // Register select bit
#define EN_BIT 2 // Enable bit
#define BL_BIT 3 // Backlight bit
#define D4_BIT 4 // Data 4 bit
#define D5_BIT 5 // Data 5 bit
#define D6_BIT 6 // Data 6 bit
#define D7_BIT 7 // Data 7 bit
#define LCD_ROWS 2 // Number of rows on the LCD
#define LCD_COLS 16 // Number of columns on the LCD

#define PRESSURE 30

int backlight_state = 1;

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;

I2C_HandleTypeDef hi2c2;

LPTIM_HandleTypeDef hlptim1;

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart3;
DMA_HandleTypeDef hdma_usart3_rx;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_TIM4_Init(void);
static void MX_I2C2_Init(void);
static void MX_LPTIM1_Init(void);
static void MX_TIM3_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM1_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_NVIC_Init(void);
/* USER CODE BEGIN PFP */
// BME680 Forward Declarations
int8_t bme680I2cRead(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t len);
int8_t bme680I2cWrite(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t len);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
#define addrRCC 0x40021000
#define offsetAHB 0x4C
#define baseGPIOC 0x48000800
#define offsetModer 0x00
#define offsetOTYPER 0x04


uint16_t ADC_Data = 0;
int ADC_Converted = 0;

long map(long x, long in_min, long in_max, long out_min, long out_max)
{
	return (x - in_min) * (out_max - out_min + 1) / (in_max - in_min + 1) + out_min;
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	ADC_Converted = map(ADC_Data, 0, 4095, 50, 100);
	TIM2->CCR1 = ADC_Converted;
}

void lcd_write_nibble(uint8_t nibble, uint8_t rs) {
	uint8_t data = nibble << D4_BIT;
	data |= rs << RS_BIT;
	data |= backlight_state << BL_BIT; // Include backlight state in data
	data |= 1 << EN_BIT;
	HAL_I2C_Master_Transmit(&hi2c2, I2C_ADDR << 1, &data, 1, 100);
	HAL_Delay(1);
	data &= ~(1 << EN_BIT);
	HAL_I2C_Master_Transmit(&hi2c2, I2C_ADDR << 1, &data, 1, 100);
}

void lcd_send_cmd(uint8_t cmd) {
	uint8_t upper_nibble = cmd >> 4;
	uint8_t lower_nibble = cmd & 0x0F;
	lcd_write_nibble(upper_nibble, 0);
	lcd_write_nibble(lower_nibble, 0);
	if (cmd == 0x01 || cmd == 0x02) {
		HAL_Delay(2);
	}
}

void lcd_send_data(uint8_t data) {
	uint8_t upper_nibble = data >> 4;
	uint8_t lower_nibble = data & 0x0F;
	lcd_write_nibble(upper_nibble, 1);
	lcd_write_nibble(lower_nibble, 1);
}

void lcd_init() {
	HAL_Delay(50);
	lcd_write_nibble(0x03, 0);
	HAL_Delay(5);
	lcd_write_nibble(0x03, 0);
	HAL_Delay(1);
	lcd_write_nibble(0x03, 0);
	HAL_Delay(1);
	lcd_write_nibble(0x02, 0);
	lcd_send_cmd(0x28);
	lcd_send_cmd(0x0C);
	lcd_send_cmd(0x06);
	lcd_send_cmd(0x01);
	HAL_Delay(2);
}

void lcd_set_cursor(uint8_t row, uint8_t column) {
    uint8_t address;
    switch (row) {
        case 0:
            address = 0x00;
            break;
        case 1:
            address = 0x40;
            break;
        default:
            address = 0x00;
    }
    address += column;
    lcd_send_cmd(0x80 | address);
}

void lcd_write_string(char *str) {
	while (*str) {
		lcd_send_data(*str++);
	}
}

void lcd_clear(void) {
	lcd_send_cmd(0x01);
    HAL_Delay(2);
}

void show_lcd(int param){

	char *text = "Current Phase";
	char int_to_str[50];
	int an_int = param;

	lcd_clear();
	lcd_set_cursor(0, 0);
	lcd_write_string(text);
	lcd_set_cursor(1, 0);
	sprintf(int_to_str, "%d", an_int);
	lcd_write_string(int_to_str);
	HAL_Delay(100);
}

#define CLOCKWISE 0
#define COUNTERCLOCKWISE 1

void up_run_counterclockwise(){
	TIM4->CCR2 = 0; //LED BLUE
	TIM4->CCR3 = 500;  //Vertical up
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //Vertical up
	HAL_Delay(1000);
}

void up_run_clockwise(){
	TIM4->CCR2 = 1000; //LED BLUE
	TIM4->CCR3 = 500;  //Vertical up
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //Vertical up
	HAL_Delay(1000);
}

void down_run_counterclockwise(){
	TIM3->CCR2 = 0; //LED GREEN
    TIM4->CCR4 = 500;  //Vertical down
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);//Vertical down
	HAL_Delay(1000);
}

void down_run_clockwise(){
	TIM3->CCR2 = 1000; //LED GREEN
    TIM4->CCR4 = 500;  //Vertical down
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);//Vertical down
	HAL_Delay(1000);
}

void seed_dropping_logic(){

    int dir_up = CLOCKWISE;
    int dir_down = CLOCKWISE;


 	volatile int x = 1, y = 1;
	volatile int m = 1, n = 1;

	while(1){

		if((x == 0 || m == 0) && dir_up == CLOCKWISE){
	    	dir_up = COUNTERCLOCKWISE;
	    	up_run_counterclockwise();
	    }
	    else if((x == 0 || m == 0) && dir_up == COUNTERCLOCKWISE){
	    	dir_up = CLOCKWISE;
	    	up_run_clockwise();
	    }

	    if((y == 0 || n == 0) && dir_down == CLOCKWISE){
	    	dir_down = COUNTERCLOCKWISE;
	    	down_run_counterclockwise();
	    }
	    else if((y == 0 || n == 0) && dir_down == COUNTERCLOCKWISE){
	    	dir_down = CLOCKWISE;
	    	down_run_clockwise();
	    }

	    if(dir_up == COUNTERCLOCKWISE){
	    	TIM4->CCR3 = 0;  //Vertical up
	    	TIM4->CCR2 = 0; //LED BLUE
	    }
	    else{
	    	TIM4->CCR3 = 500;  //Vertical up
	    	TIM4->CCR2 = 1000; //LED BLUE
	       	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //Vertical up
	    }
		if(dir_down == COUNTERCLOCKWISE){
	    	TIM4->CCR4 = 0;  //Vertical down
	       	TIM3->CCR2 = 0; //LED GREEN
	    }
	    else{
	    	TIM4->CCR4 = 500;  //Vertical down
	    	TIM3->CCR2 = 1000; //LED GREEN
	    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);//Vertical down
	    }
	    if(dir_up == COUNTERCLOCKWISE && dir_down == COUNTERCLOCKWISE){
	    	break;
	    }
	    x = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1);
		y = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2);
		m = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3);
		n = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
	}

	x = 1;
	y = 1;
	m = 1;
	n = 1;

	HAL_Delay(5000);

	while(1){
	    if((x == 0 || m == 0) && dir_up == CLOCKWISE){
	    	dir_up = COUNTERCLOCKWISE;
	    	up_run_counterclockwise();
	    }
	    else if((x == 0 || m == 0) && dir_up == COUNTERCLOCKWISE){
	    	dir_up = CLOCKWISE;
	    	up_run_clockwise();
	    }

	    if((y == 0 || n == 0) && dir_down == CLOCKWISE){
	        dir_down = COUNTERCLOCKWISE;
	        down_run_counterclockwise();
	    }
	    else if((y == 0 || n == 0) && dir_down == COUNTERCLOCKWISE){
	        dir_down = CLOCKWISE;
	        down_run_clockwise();
	    }

	    if(dir_up == CLOCKWISE){
	    	TIM4->CCR2 = 0; //LED BLUE
	        TIM4->CCR3 = 0;  //Vertical up
	    }
	    else{
	    	TIM4->CCR2 = 1000; //LED BLUE

	        TIM4->CCR3 = 500;  //Vertical up
	       	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //Vertical up
	    }

	    if(dir_down == CLOCKWISE){
	    	TIM4->CCR4 = 0;  //Vertical down
	        TIM3->CCR3 = 0; //seeds
	       	TIM3->CCR2 = 0; //LED GREEN
	    }
	    else{
	    	TIM4->CCR4 = 500;  //Vertical down
	    	TIM3->CCR3 = 500; //seeds
	    	TIM3->CCR2 = 1000; //LED GREEN
	    	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);//Vertical down
	    }
	    if(dir_up == CLOCKWISE && dir_down == CLOCKWISE){
	    	break;
	    }
	   	x = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1);
		y = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2);
		m = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3);
		n = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
	}

    /*
	TIM4->CCR2 = 100; //LED BLUE
	TIM3->CCR2 = 100; //LED GREEN


	volatile int x = 1, y = 1;
	volatile int m = 1, n = 1;

    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET);
	TIM4->CCR3 = 500;  //Vertical up
    TIM3->CCR3 = 0; //seeds
	while(x == 1 && y == 1 && m == 1 && n == 1){
		TIM4->CCR2 = (x + y) * 500; //LED BLUE
		TIM3->CCR2 = (m + n) * 500; //LED GREEN
		HAL_Delay (1);  // wait for 2 beeps
		x = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1);
		y = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2);
		m = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3);
		n = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
	}

	x = 1;
	y = 1;
	m = 1;
	n = 1;


	up_run_counterclockwise();
    TIM3->CCR3 = 0; //seeds
    TIM4->CCR3 = 0;  //Vertical up
	HAL_Delay(1000);

	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET);
	TIM4->CCR3 = 500;  //Vertical up
	TIM3->CCR3 = 500; //seeds
	while(x == 1 && y == 1 && m == 1 && n == 1){
		TIM4->CCR2 = (x + y) * 500; //LED BLUE
		TIM3->CCR2 = (m + n) * 500; //LED GREEN
		HAL_Delay (1);  // wait for 2 beeps
		x = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1);
		y = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2);
		m = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3);
		n = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
	}
	x = 1;
	y = 1;
	m = 1;
	n = 1;

	up_run_clockwise();
    TIM3->CCR3 = 0; //seeds
    TIM4->CCR3 = 0;  //Vertical up
    HAL_Delay (1000);

	TIM4->CCR2 = 100; //LED BLUE
	TIM3->CCR2 = 100; //LED GREEN
    TIM3->CCR3 = 0; //seeds
    TIM4->CCR3 = 0;  //Vertical up

	//show_lcd(3);
	//HAL_Delay(5000);
	 *
	 */
}

struct bme680_dev gas_sensor;

void maintaince_logic(uint16_t min_sampling_period){

	struct bme680_field_data data;

	char rec[5] = "";

	HAL_UART_Transmit(&huart3,"begin",5,1000);

	int num = 0;

	while(num < 2){
		int rslt;
	    HAL_Delay(min_sampling_period);
	    rslt = bme680_get_sensor_data(&data, &gas_sensor);
	    uint8_t i2c_reading_buf[100];
	    sprintf((char *)i2c_reading_buf,
	    			"Temperature\n%u.%u degC\nHumidity\n%u.%u %%rH\r\n",
	    		    (unsigned int)data.temperature / 100,
	    		    (unsigned int)data.temperature % 100,
	    		    (unsigned int)data.humidity / 1000,
	    		    (unsigned int)data.humidity % 1000);
	    /*lcd_clear();
	    lcd_set_cursor(0, 0);
	    lcd_write_string(i2c_reading_buf);*/
	    HAL_UART_Transmit(&huart3,(uint8_t *)i2c_reading_buf,strlen(i2c_reading_buf),1000);
	    HAL_Delay(5000);
	    if (gas_sensor.power_mode == BME680_FORCED_MODE) {
	    	rslt = bme680_set_sensor_mode(&gas_sensor);
	    }
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, 1);
		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_11, 0);

		HAL_Delay(min_sampling_period);
		rslt = bme680_get_sensor_data(&data, &gas_sensor);
		sprintf((char *)i2c_reading_buf,
					"Temperature\n%u.%u degC\nHumidity\n%u.%u %%rH\r\n",
				    (unsigned int)data.temperature / 100,
				    (unsigned int)data.temperature % 100,
				    (unsigned int)data.humidity / 1000,
				    (unsigned int)data.humidity % 1000);
		/*lcd_clear();
		lcd_set_cursor(0, 0);
		lcd_write_string(i2c_reading_buf);*/
		HAL_UART_Transmit(&huart3,(uint8_t *)i2c_reading_buf,strlen(i2c_reading_buf),1000);
		HAL_Delay(5000);
		if (gas_sensor.power_mode == BME680_FORCED_MODE) {
			rslt = bme680_set_sensor_mode(&gas_sensor);
		}
    	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, 0);
    	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_11, 1);
    	HAL_UART_Receive (&huart3, rec, 12, 5000);
    	if(rec[0] == 'e'){
    		break;
    	}
    	num++;
	}

	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_12, 0);
	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_11, 0);
	TIM4->CCR2 = 1000; //LED BLUE
	TIM3->CCR2 = 1000; //LED GREEN
	HAL_Delay(3000);
	TIM4->CCR2 = 0; //LED BLUE
	TIM3->CCR2 = 0; //LED GREEN
	//HAL_UART_Transmit(&huart3,"Maintenance ended!",17,1000);
}

void harvesting_logic(){

	HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET); //Vertical up
	HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);//Vertical down
	//TIM4->CCR3 = 500;  //Vertical up
	TIM4->CCR4 = 500;  //Vertical down

	volatile int x = 1, y = 1;
	volatile int m = 1, n = 1;

	while(x == 1 && y == 1 && m == 1 && n == 1){
		x = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1);
				y = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2);
				m = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3);
				n = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
	}

    TIM4->CCR4 = 0;  //Vertical down

	down_run_clockwise();

    TIM4->CCR4 = 0;  //Vertical down

    //----------------------SERVO MOVEMENT------------------------
    __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 420);
    HAL_Delay(1000);
    //------------------------------------------------------------

	TIM2->CCR1 = 50; // BLDC
	HAL_Delay(1000);
	for(int i = 50; i > 56; i++){
		TIM2->CCR1 = i;  // BLDC
    	TIM4->CCR2 = 100; //LED BLUE
    	TIM3->CCR2 = 100; //LED GREEN
		HAL_Delay(10);
	}

	TIM2->CCR1 = 56;
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //Vertical up
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);//Vertical down
    TIM4->CCR4 = 500;  //Vertical down

    x = 1;
    y = 1;
    m = 1;
    n = 1;

    while(x == 1 && y == 1 && m == 1 && n == 1){
    	x = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1);
    			y = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_2);
    			m = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_3);
    			n = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4);
    }

    TIM4->CCR4 = 0;  //Vertical down
	for(int i = 56; i > 50; i--){
		TIM2->CCR1 = i;  // BLDC
    	TIM4->CCR2 = 100; //LED BLUE
    	TIM3->CCR2 = 100; //LED GREEN
		HAL_Delay(10);
	}
	TIM2->CCR1 = 0;
	__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 250);
	HAL_Delay(1000);
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_TIM4_Init();
  MX_I2C2_Init();
  MX_LPTIM1_Init();
  MX_TIM3_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM1_Init();
  MX_USART3_UART_Init();

  /* Initialize interrupts */
  MX_NVIC_Init();
  /* USER CODE BEGIN 2 */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_SET);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_2);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);
  HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_4);
  HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);

  TIM4->CCR2 = 100; //LED BLUE
  TIM4->CCR3 = 0;  //Vertical up
  TIM4->CCR4 = 0;  //Vertical down
  TIM3->CCR2 = 100; //LED GREEN
  TIM3->CCR3 = 0; //seeds
  __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 250);

#if Calibrate
  TIM2->CCR1 = 100;  // Set the maximum pulse (2ms)
  HAL_Delay (2000);  // wait for 1 beep
  TIM2->CCR1 = 50;   // Set the minimum Pulse (1ms)
  HAL_Delay (1000);  // wait for 2 beeps
  TIM2->CCR1 = 0;    // reset to 0, so it can be controlled via ADC
#endif

	uint32_t* addrAHB = (uint32_t*) (addrRCC + offsetAHB);
	*addrAHB |= (0xFFFFFFFB & *addrAHB) + 0x4;

	uint32_t* addrGPIOC_Mode = (uint32_t*)(baseGPIOC + offsetModer);
	*addrGPIOC_Mode |= (0xFCFFFFFF & *addrGPIOC_Mode) | 0x01000000;

	uint32_t* addrGPIOC_Type = (uint32_t*)(baseGPIOC + offsetOTYPER);
	*addrGPIOC_Type |= 0xFFFFBFFF & *addrGPIOC_Type;

  //HAL_ADC_Start_DMA(&hadc1, (uint32_t *)&ADC_Data, 1);

	  // Configure the BME680 driver
		  int rslt;

		  // Configure the BME680 driver
		  gas_sensor.dev_id = BME680_I2C_ADDR_SECONDARY;
		  gas_sensor.intf = BME680_I2C_INTF;
		  gas_sensor.read = bme680I2cRead;
		  gas_sensor.write = bme680I2cWrite;
		  gas_sensor.delay_ms = HAL_Delay;
		  gas_sensor.amb_temp = 25;

		  // Initialize the driver
		  if (bme680_init(&gas_sensor) != BME680_OK) {
		    uint8_t bme_msg[] = "BME680 Initialization Error\r\n";
		  } else {
		    uint8_t bme_msg[] = "BME680 Initialized and Ready\r\n";
		  }

		  // Select desired oversampling rates
		  gas_sensor.tph_sett.os_hum = BME680_OS_2X;
		  gas_sensor.tph_sett.os_pres = BME680_OS_4X;
		  gas_sensor.tph_sett.os_temp = BME680_OS_8X;

		  // Set sensor to "always on"
		  gas_sensor.power_mode = BME680_FORCED_MODE;

		  // Set oversampling settings
		  uint8_t required_settings = (BME680_OST_SEL | BME680_OSP_SEL | BME680_OSH_SEL);
		  rslt = bme680_set_sensor_settings(required_settings, &gas_sensor);

		  // Set sensor mode
		  rslt = bme680_set_sensor_mode(&gas_sensor);

		  // Query minimum sampling period
		  uint16_t min_sampling_period;
		  bme680_get_profile_dur(&min_sampling_period, &gas_sensor);

		  // Sampling results variable

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */

    TIM4->CCR2 = 1000; //LED BLUE
    TIM4->CCR3 = 0;  //Vertical up
    TIM4->CCR4 = 0;  //Vertical down
    TIM3->CCR2 = 1000; //LED GREEN
    TIM3->CCR3 = 0; //seeds
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_SET); //Vertical up
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_SET);//Vertical down
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_SET);//Seeds

    HAL_Delay(1000);

    while (1)
    {
 /*   		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 210);
    		HAL_Delay(1000);
*/
    	HAL_UART_Transmit(&huart3,"begin program",5,1000);
    	seed_dropping_logic();
    	maintaince_logic(min_sampling_period);
    	harvesting_logic();
    	HAL_UART_Transmit(&huart3,"end program",5,1000);
    	//__HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, 0);
/*
    		__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 90);
			HAL_Delay(1000);

			//maintaince_logic(min_sampling_period);

			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 210);
			HAL_Delay(1000);



			__HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 90);
			HAL_Delay(1000);
*/
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, 180);
    __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, 180);
    TIM4->CCR2 = 0; //LED BLUE
    TIM4->CCR3 = 0;  //Vertical up
    TIM4->CCR4 = 0;  //Vertical down
    TIM3->CCR2 = 0; //LED GREEN
    TIM3->CCR3 = 0; //seeds
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_MSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief NVIC Configuration.
  * @retval None
  */
static void MX_NVIC_Init(void)
{
  /* TIM4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM4_IRQn, 1, 0);
  HAL_NVIC_EnableIRQ(TIM4_IRQn);
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV1;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_1;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_2CYCLES_5;
  sConfig.SingleDiff = ADC_DIFFERENTIAL_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = 0x00000E14;
  hi2c2.Init.OwnAddress1 = 238;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief LPTIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_LPTIM1_Init(void)
{

  /* USER CODE BEGIN LPTIM1_Init 0 */

  /* USER CODE END LPTIM1_Init 0 */

  /* USER CODE BEGIN LPTIM1_Init 1 */

  /* USER CODE END LPTIM1_Init 1 */
  hlptim1.Instance = LPTIM1;
  hlptim1.Init.Clock.Source = LPTIM_CLOCKSOURCE_APBCLOCK_LPOSC;
  hlptim1.Init.Clock.Prescaler = LPTIM_PRESCALER_DIV128;
  hlptim1.Init.Trigger.Source = LPTIM_TRIGSOURCE_SOFTWARE;
  hlptim1.Init.OutputPolarity = LPTIM_OUTPUTPOLARITY_HIGH;
  hlptim1.Init.UpdateMode = LPTIM_UPDATE_IMMEDIATE;
  hlptim1.Init.CounterSource = LPTIM_COUNTERSOURCE_INTERNAL;
  hlptim1.Init.Input1Source = LPTIM_INPUT1SOURCE_GPIO;
  hlptim1.Init.Input2Source = LPTIM_INPUT2SOURCE_GPIO;
  if (HAL_LPTIM_Init(&hlptim1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN LPTIM1_Init 2 */

  /* USER CODE END LPTIM1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 39;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 1999;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 180;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCNPolarity = TIM_OCNPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 79;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 999;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 19;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 999;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 19;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 999;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 50;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 9600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart3, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart3, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMAMUX1_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
  /* DMA1_Channel2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel2_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOF_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_6, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_11|GPIO_PIN_12, GPIO_PIN_SET);

  /*Configure GPIO pins : PA1 PA2 PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PA3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PB15 */
  GPIO_InitStruct.Pin = GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : PC6 */
  GPIO_InitStruct.Pin = GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PC11 PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PB3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

int8_t bme680I2cRead(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t len) {
  int8_t result;

  if (HAL_I2C_Master_Transmit(&hi2c2, (dev_id << 1), &reg_addr, 1, 10) != HAL_OK) {
    result = -1;
  } else if (HAL_I2C_Master_Receive (&hi2c2, (dev_id << 1) | 0x01, reg_data, len, 10) != HAL_OK) {
    result = -1;
  } else {
    result = 0;
  }

  return result;
}

int8_t bme680I2cWrite(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t len) {
  int8_t result;
  int8_t *buf;

  // Allocate and load I2C transmit buffer
  buf = malloc(len + 1);
  buf[0] = reg_addr;
  memcpy(buf + 1, reg_data, len);

  if (HAL_I2C_Master_Transmit(&hi2c2, (dev_id << 1), (uint8_t *) buf, len + 1, HAL_MAX_DELAY) != HAL_OK) {
    result = -1;
  } else {
    result = 0;
  }

  free(buf);
  return result;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
